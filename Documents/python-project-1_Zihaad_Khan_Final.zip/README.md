# Creating Python programs in Codio

### Make a new file
Use **File > New File...** or right-click in the file tree to create a new file. You can right-click in the file tree to rename or delete files.

As Codio detects which file is in focus, simply put your cursor into whichever code editor you want to run.

### Run your code
Use the Run button (that looks like a Rocketship) to Run the file your cursor is in.

### Debug your code
Use the "Debug Current File" on the far right of the top menu bar to launch the debugger targeting the file your cursor is in.

### Reconfigure your Panels for easier development
Use the **View > Panels** menu on the top tool bar to segment your screen.

Simply drag the tab of the file or terminal (the part with the name) you want to move into the new panel.

### Using Python
Open up a terminal window from the **Tools->Terminal** menu.

### I expected to see the Instructions for this assessment.
Select **Tools->Guide->Play** to view the Guide for this project.
![playGuide](https://global.codio.com/platform/readme.resources/playGuide.png)
