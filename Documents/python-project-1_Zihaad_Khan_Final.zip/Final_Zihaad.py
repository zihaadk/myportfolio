import hashlib #haslib library used for encrypting passwords
import sys #used to access system-specific parameters

"""We will use a dictionary to store key-value pairs of the usernames and encrypted passwords of users that has access to the system.
- Ideally this would be stored securely in a database but for demonstrative purposes it should be sufficient
- Encryption was performed prior using test_encryption.py attached"""

valid_users = {'John':'a702fcdd87ee2c684d20ffca15f12df5b2bf1714a2a42eb35798770e62d9b21f', 'Mary':'fce9c92669132ff047b94cbdf11f66382ba90c147ca94b3cc19c26dd3e8e885c', 'Amy':'2f97abfd360124ced5e1bd88ad8d880913d57fefa05eb407c9b67a6cad9cf2f4'}

class UserInfo:
    """This class stores a username and an encrypted password"""

    def __init__(self, username, password):
        """Create a new user object. This function also calls in 'encrypt_pw'. The password will be encrypted before storing. This function was extracted from (Phillips, 2015)"""
        self.username = username
        self.password = self._encrypt_pw(password)
        self.is_logged_in = False

    def _encrypt_pw(self, password):
        """ Encrypt the password with the username by adding the username and password then return the sha digest. This function was extracted from (Phillips, 2015)"""
        hash_string = (self.username + password)
        hash_string = hash_string.encode("utf8")
        return hashlib.sha256(hash_string).hexdigest()

    def check_password(self, password):
        """Return True if the password is valid for this user, false otherwise. This function was extracted from (Phillips, 2015)"""
        encrypted = self._encrypt_pw(password)
        return encrypted == self.password

class PatientInfo:
    """This class defines the patient information - all variables are categorised as string"""
    def __init__(self, patientid, firstname, lastname, address, emailadd, dob, gender, allergies):
        self.patientid = patientid
        self.firstname = firstname
        self.lastname = lastname
        self.address = address
        self.emailadd = emailadd
        self.dob = dob
        self.gender = gender
        self.allergies = allergies
        return

"""Patient 1 information is hardcoded into a list for demonstrative purposes"""
Patient_1 = PatientInfo("1001", "John", "Doe", "Sandton - South Africa", "john@gmail.com", "20/05/1988", "Male", "None")

class PatientClass:
    """This function is used to print out patient fields"""

    def patient_record(self):
        print("\nWelcome to the Patient Class - The patient details on record is the following:")
        print("\nPatient ID: ", Patient_1.patientid)
        print("First Name: ", Patient_1.firstname)
        print("Last Name: ", Patient_1.lastname)
        print("Address: ", Patient_1.address)
        print("E-mail address: ", Patient_1.emailadd)
        print("Date of Birth: ", Patient_1.dob)
        print("Gender is: ", Patient_1.gender)
        print("Patient has indicated: ", Patient_1.allergies, " for allergies")
        print("\n***Further actions for this class would be to book an appointment but this is out of scope for the current program***\n")
        return

class MedicalClass:
    """This is a Medical class used to define patient medical records"""

    def medical_record(self):
        print("\nWelcome to the Medical History Class\n")
        print("\n***Further actions for this class would be to view medical history records but this is out of scope for the current program***\n")
        #Various functions can be written here to access medical records
        return

class AppointmentClass:
    """This is an Appointment class used to manage appointments requested by patients"""

    def appointments(self):
        print("\nWelcome to the Appointment Management Class\n")
        print("\n***Further actions for this class would be to manage appointments but this is out of scope for the current program***\n")
        # Various functions can be written here to access appointment information
        return

class BillingClass:
    """This is a Billing class used to define patient account information"""

    def bills(self):
        print("\nWelcome to the Billing Class\n")
        print("\n***Further actions for this class would be to generate billing accounts but this is out of scope for the current program***\n")
        # Various functions can be written here to access billing information
        return

class SpecialistClass:
    """This is a specialist class used to define access to other classes for dr's"""

    def specialist_options(self):
        print("\nWelcome to the Specialist Class\n")
        choices: List[str] = ["1 - View Patient Records", "2 - Update Medical History", "3 - Manage Appointments", "4 - Generate Account Bills", "5 - Return to Main Menu"]
        for option in choices:
            print(choices)
            print("\n")
            option = input("Please choose an option by indicating the number: \n")
            if option == '1':
                PatientClass.patient_record(self)

            elif option == '2':
                MedicalClass.medical_record(self)

            elif option == '3':
                AppointmentClass.appointments(self)

            elif option == '4':
                BillingClass.bills(self)

            elif option == '5':
                break

            else:
                print("\nInvalid Option - Please enter a valid option\n")
                SpecialistClass.specialist_options(self)
        return option


class ReceptionistClass:
    """This is a receptionist class used to define the access to other classes for receptionist users """

    def reception(self):
        print("\nWelcome to the Receptionist Class\n")
        reception_choices: List[str] = ["1 - Manage Appointments","2 - Generate Account Bills", "3 - Return to Main Menu"]
        for option in reception_choices:
            print(reception_choices)
            print("\n")
            option = input("Please choose an option by indicating the number: \n")
            if option == '1':
                AppointmentClass.appointments(self)

            elif option == '2':
                BillingClass.bills(self)

            elif option == '3':
                break

            else:
                print("\nInvalid Option - Please enter a valid option\n")
                ReceptionistClass.reception(self)
        return option


class PermissionClass:
    """This is a permission class to check which roles the users have access to"""

    def __init__(self):
        """Users are hard coded with usernames and encrypted passwords stored in a dictionary for ease of use"""
        self.patient_users = {'John':'a702fcdd87ee2c684d20ffca15f12df5b2bf1714a2a42eb35798770e62d9b21f'}
        self.specialist_users = {'Mary':'fce9c92669132ff047b94cbdf11f66382ba90c147ca94b3cc19c26dd3e8e885c'}
        self.receptionist_users = {'Amy':'2f97abfd360124ced5e1bd88ad8d880913d57fefa05eb407c9b67a6cad9cf2f4'}

    def check_user(self,username):

        if username in self.patient_users.keys():
            PatientClass.patient_record(self)  #Call a class to be able to read the patients information

        if username in self.specialist_users.keys():
            SpecialistClass.specialist_options(self)  #Call the specialist class for this level of access

        if username in self.receptionist_users.keys():
            ReceptionistClass.reception(self)  #call the receptionist class for this level of access

    def login_menu(self):
        login_attempts = 0
        while True:
            username = input("\nPlease enter your username to access ASMIS?\n")

            """We could possibly use a function like 'Getpass' here to hide the password on screen while being entered - further enhancing security"""

            password = input("\nPlease enter your password?\n")
            user_info = UserInfo(username, password)

            """Only allow the user to enter credentials a max of 3 times thereafter terminate"""

            if login_attempts == 3:
                sys.exit("Sorry you could not be authenticated - there were too many failed attempts, please try again later.")

            """Check if the user is valid by validating against dictionary created above"""

            if username in valid_users.keys():
                """Authenticate Users by checking if they exist in the dictionary listed"""
                if user_info.password in valid_users.values():
                    print("\nLogin Successful - Welcome to ASMIS", user_info.username)

                    """Now we will go into the permission class to check the permission of the user"""
                    PermissionClass().check_user(username)
                    break
                else:
                    print("Password entered incorrectly.")
                    login_attempts += 1
            else:
                print("Username entered incorrectly.")
                login_attempts += 1

class MainMenu:
    def menu(self):
        """A simple menu option created once exited from a class"""
        while True:
            menuoption = input("\nPress '1' to login with another user or '2' to exit the program: ")
            if menuoption == '1':
                PermissionClass().login_menu()
            elif menuoption == '2':
                break
            else:
                print ("Option is invalid")

PermissionClass().login_menu()
MainMenu().menu()
print("\nThank you for using ASMIS - End of Program")









