By Zihaad Khan (zk21980@essex.ac.uk)

Requirements of the Project
----------------------------

It was required to implement a Python code of at least one solution recommended as part of the report submitted in Unit 9. 

Solution
--------

The code achieves the following objectives:

1. Performs encryption of user passwords that are entered into the program, these passwords are then validated against the hard coded encrypted passwords.
2. Users are only allowed to log in to the program a maximum of 4 times with incorrect credentials i.e. username & password - in order to prevent brutte force attacks
3. Performs role based access control (RBAC) to access specific classes based on usernames.

Decscription
------------

The program assumes that users have already been registered with a username and a password that complies with the minimum password complexity requirements i.e the length of the passwords > 8 characters and must contain 1 number and 1 special character.

3 Users exist on the system with different roles used to access different classes i.e.

# John  - A patient
# Mary  - A specialist
# Amy   - A receptionist

The usernames and passwords are provided in the "test_data" file in the /home/codio/workspace directory. These passwords were encrypted and entered into the code for password validation when logging in.

The "test_encryption.py" file was used to obtain encrypted passwords. 

The base code for this script was extracted from the following book:
# Phillips, D. (2015) Python 3 Object-Oriented Programming. 2nd Ed. PACKT Publishing.

A user assigned to a patient role is only allowed to access Patient Classes and are able to view the follolwing patient information:

#Patient ID
#First Name
#Last Name
#Address
#E-Mail Address
#Date of Birth
#Gender
#Allergies

A user assigned to a Specialist role can access the following information:

#View Patient Records
#Update Medical History
#Manage Appointments
#Generate Account Bills

A user assigned to a Receptionist role can access the following information:

#Manage Appointments
#Generate Account Bills

IT SHOULD BE NOTED THAT NO INFORMATION EXISTS IN THE FOLLOWING CLASSES AS THE PROGRAM DEMONSTRATES ACCESS TO THE CLASSES ONLY:

#Update Medical History
#Manage Appointments
#Generate Account Bills

The code does not allow any inputs or updates to patient information, sample patient data is hard coded in a list format for demonstrative purposes.

Program Execution
-----------------

The script can be executed by running #python3 Final_Zihaad.py from a terminal

A sample output file called: sample_output_Final_Zihaad.txt has also been saved in the /home/codio/workspace directory. This provides the output when the 3 different users log in as well as failed password attempts.

Future Work/Enhacements to the Code
-----------------------------------

1. The program is based on a simple login and a role based control access method. Future enhancements to the program can be performed by integrating the code into a MYSQL database as well. Usernames and passwords can be stored securely in a database. Further enhancements (adding more options to relevant classes) can also be performed.
2. Liraries such as "inquirer" (https://pypi.org/project/inquirer/) can also be imported and used to enhance the list and select functionalities within the classes.
3. When passwords are entered onto the screen during the login process - they are visible, these can be configured to depict Asterisks (*) preventing onlookers from viewing passwords.
4. A user registration/sign class/fucntion can be configured to allow users to sign up as a prospective patient on the system.

References
----------

Phillips, D. (2015) Python 3 Object-Oriented Programming: Unleash the power of Python 3 objects. 2nd ed. PACKT Publishing. Packt Publishing Ltd. Available from: https://library.kre.dp.ua/Books/2-4%20kurs/Програмування%20%2B%20мови%20програмування/Python/Python_3_Object_Oriented_Programming.pdf. [Accessed 20 October 2021]

Phillips, D. (2018) Python 3 Object-oriented programming: Build robust and maintainable software with object-oriented design patterns in Python 3.8. 3rd ed. Birmingham: Packt Publishing Ltd.

PYTHON ORG. (2021) Python. Available from: https://www.python.org. [Accessed 20 October 2021]





