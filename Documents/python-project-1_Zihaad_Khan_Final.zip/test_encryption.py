#The base code for this script was extracted from the following book:
# Phillips, D. (2015) Python 3 Object-Oriented Programming. 2nd Ed. PACKT Publishing.
#[Accessed 20 October 2021]

#The Script contains 1 class with 3 methods used to read in a username and password and thereafter encrypt the password
#using sha256 and the hashlib library

#Executing the script is performed from a terminal as follows # python test_encryption.py

import hashlib

class UserInfo:
    """This class stores a username and an encrypted password"""

    def __init__(self, username, password):
        """Create a new user object. This function also calls in 'encrypt_pw'. The password will be encrypted before storing."""
        self.username = username
        self.password = self._encrypt_pw(password)
        self.is_logged_in = False

    def _encrypt_pw(self, password):
        """ Encrypt the password with the username by adding the username and password then return the sha digest."""
        hash_string = (self.username + password)
        hash_string = hash_string.encode("utf8")
        return hashlib.sha256(hash_string).hexdigest()

    def check_password(self, password):
        """Return True if the password is valid for this user, false otherwise."""
        encrypted = self._encrypt_pw(password)
        return encrypted == self.password

username = input("Please enter your username to access ASMIS?\n")
password = input("Please enter your password?\n")
userinfo = UserInfo(username, password)
print("Thank you, for security purposes your password has now been encrypted")
print("Your username is:", userinfo.username, "and your encrypted password is:", userinfo.password, userinfo.check_password(password))


#===================================================================================================================
#This is an example of the Output
#/usr/local/bin/python3.8 "/Users/zihaad/Library/Application Support/JetBrains/PyCharmCE2020.1/scratches/testencryption.py"
#Please enter your username to access ASMIS?
#Amy
#Please enter your password?
#A$terf@12
#Thank you, for security purposes your password has now been encrypted
#Your username is: Amy and your encrypted password is: 2f97abfd360124ced5e1bd88ad8d880913d57fefa05eb407c9b67a6cad9cf2f4 True
#
#Process finished with exit code 0
#==================================================================================================================